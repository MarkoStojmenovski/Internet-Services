﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using midTerm.Models.Models.Option;
using midTerm.Services.Abstractions;

namespace midTerm.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OptionController : ControllerBase
    {
        private readonly IOptionService _service;

        public OptionController(IOptionService service)
        {
            _service = service;
        }

        //api/Options/id/1
        [HttpGet("Options/{id:int}", Name = nameof(GetOptions))]
        public async Task<IActionResult> GetOptions([FromRoute] int id)
        {
            var result = await _service.GetByQuestionId(id);
            return result != null
                ? Ok(result)
                : NoContent();
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] OptionCreateModel model)
        {
            if (ModelState.IsValid)
            {
                var item = await _service.Insert(model);

                if (item != null)
                {
                    return Created($"/api/Options/{item.Id}", item.Id);
                }
                return Conflict();
            }
            return BadRequest();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put([FromRoute] int id, [FromBody] OptionUpdateModel model)
        {
            if (ModelState.IsValid)
            {
                model.Id = id;
                var item = await _service.Update(model);

                return item != null
                    ? Ok(item)
                    : NoContent();
            }
            return BadRequest();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (ModelState.IsValid)
            {
                return Ok(await _service.Delete(id));
            }
            return BadRequest();
        }
    }
}
