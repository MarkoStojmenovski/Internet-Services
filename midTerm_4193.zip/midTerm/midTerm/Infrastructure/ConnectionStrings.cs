﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace midTerm.Infrastructure
{
    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
    }
}
