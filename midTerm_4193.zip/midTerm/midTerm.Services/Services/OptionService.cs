﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using midTerm.Data;
using midTerm.Data.Entities;
using midTerm.Models.Models.Option;
using midTerm.Services.Abstractions;

namespace midTerm.Services.Services
{
    public class OptionService : IOptionService
    {
        private readonly midTermDbContext _context;
        private readonly IMapper _mapper;

        public OptionService(midTermDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IEnumerable<OptionModel>> GetByQuestionId(int id)
        {
            var questions = await _context.Options
                .Include(a => a.Question)
                .Where(a => a.QuestionId == id).ToListAsync();

            return _mapper.Map<IEnumerable<OptionModel>>(questions);
        }

        public async Task<OptionModel> Insert(OptionCreateModel model)
        {
            var entity = _mapper.Map<Option>(model);
            await _context.Options.AddAsync(entity);
            await SaveAsync();

            return _mapper.Map<OptionModel>(entity);
        }

        public async Task<OptionModel> Update(OptionUpdateModel model)
        {
            var entity = _mapper.Map<Option>(model);

            _context.Options.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;

            await SaveAsync();

            return _mapper.Map<OptionModel>(entity);
        }
        public async Task<bool> Delete(int id)
        {
            var entity = await _context.Options.FindAsync(id);
            _context.Options.Remove(entity);

            return await SaveAsync() > 0;
        }

        public async Task<int> SaveAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
