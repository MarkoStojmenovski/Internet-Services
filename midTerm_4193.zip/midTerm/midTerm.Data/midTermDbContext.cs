﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using midTerm.Data.Entities;

namespace midTerm.Data
{
    public class midTermDbContext : DbContext
    {
        public midTermDbContext(DbContextOptions<midTermDbContext> options) : base(options)
        {
        }

        public DbSet<Answer> Answers { get; set; }
        public DbSet<Option> Options { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<SurveyUser> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SurveyUser>(user =>
            {
                user.Property(p => p.FirstName).IsRequired();
                user.Property(p => p.LastName).IsRequired();
                user.Property(p => p.Gender).IsRequired();
                user.Property(p => p.Id).IsRequired();
                user.HasKey(p => p.Id);
                user.Property(p => p.FirstName).HasMaxLength(600).IsRequired();

            });

            modelBuilder.Entity<Question>(question =>
            {
                question.Property(p => p.Id).IsRequired();
                question.HasKey(p => p.Id);
                question.HasMany(p => p.Options);

            });

            modelBuilder.Entity<Answer>(answer =>
            {
                answer.Property(pm => pm.Id).IsRequired();
                answer.HasKey(pm => pm.Id);

                answer.HasOne(pm => pm.User);

                answer.HasOne(pm => pm.Option);

            });

            modelBuilder.Entity<Option>(option =>
            {
                option.Property(p => p.Id).IsRequired();
                option.HasKey(p => p.Id);

                option.HasOne(p => p.Question)
                    .WithMany(pm=>pm.Options);


            });
        }
    }
}
