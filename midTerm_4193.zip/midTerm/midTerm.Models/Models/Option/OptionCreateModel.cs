﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace midTerm.Models.Models.Option
{
    public class OptionCreateModel
    {
        [Required]
        [MaxLength(800)]
        public string Text { get; set; }
        public int? Order { get; set; }
        [Required]
        public int Question { get; set; }
    }
}
