﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using midTerm.Models.Models.Question;

namespace midTerm.Models.Models.Option
{
    public class OptionModel
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(800)]
        public string Text { get; set; }
        public int? Order { get; set; }

        public virtual QuestionModelBase Question { get; set; }
    }
}
