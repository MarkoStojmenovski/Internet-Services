﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace midTerm.Models.Models.Question
{
    public class QuestionCreateModel
    {
        [Required(ErrorMessage = "The question is required")]
        [MaxLength(800)]
        public string Text { get; set; }
        [MaxLength(800)]
        public string Description { get; set; }
    }
}
