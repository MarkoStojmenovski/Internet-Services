﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using midTerm.Data.Entities;
using midTerm.Models.Models.Option;

namespace midTerm.Models.Models.Question
{
    public class QuestionModelExtended
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(800)]
        public string Text { get; set; }
        [MaxLength(800)]
        public string Description { get; set; }

        public virtual ICollection<OptionModel> Options { get; set; }
    }
}
