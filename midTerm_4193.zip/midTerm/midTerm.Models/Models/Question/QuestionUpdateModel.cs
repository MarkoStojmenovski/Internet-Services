﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace midTerm.Models.Models.Question
{
    public class QuestionUpdateModel
    {
        [Required]
        public int Id { get; set; }
        [Required(ErrorMessage = "The question is required")]
        [MaxLength(800)]
        public string Text { get; set; }
        [Required]
        [MaxLength(800)]
        public string Description { get; set; }
    }
}
