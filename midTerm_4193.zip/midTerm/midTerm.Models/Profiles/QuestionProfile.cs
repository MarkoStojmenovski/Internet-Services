﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using midTerm.Data.Entities;
using midTerm.Models.Models.Question;

namespace midTerm.Models.Profiles
{
    public class QuestionProfile : Profile
    {
        public QuestionProfile()
        {
            CreateMap<Question, QuestionModelBase>()
                .ReverseMap();
            CreateMap<Question, QuestionModelBase>();

            CreateMap<QuestionUpdateModel, Question>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Text, opt => opt.MapFrom(src => src.Text))
                .ReverseMap();
            CreateMap<QuestionCreateModel, Question>()
                .ForMember(dest => dest.Text, opt => opt.MapFrom(src => src.Text));

        }
    }
}
