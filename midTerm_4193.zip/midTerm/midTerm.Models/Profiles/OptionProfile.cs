﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using midTerm.Data.Entities;
using midTerm.Models.Models.Option;

namespace midTerm.Models.Profiles
{
    public class OptionProfile : Profile
    {
        public OptionProfile()
        {
            CreateMap<Option, OptionModel>()
                .ReverseMap();
            CreateMap<OptionCreateModel, Option>();
            CreateMap<OptionUpdateModel, Option>();
        }
    }
}
